﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public static class GameManager {

    //Global reference to all tiles in level
    public static GameObject[] tiles;
    public static GameObject[,] grid;

}
